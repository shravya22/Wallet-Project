package hotelBooking;

import static org.junit.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.BookingPageBean;
import pages.LoginPageBean;


public class stepDef {
	private WebDriver driver;
	private LoginPageBean loginPageBean;
	private BookingPageBean bookingPageBean;
	@Before
	public void setUp()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		loginPageBean= new LoginPageBean(driver);
		bookingPageBean=new BookingPageBean(driver);
	}
	
	
	@Given("^Login page$")
	public void login_page() throws Throwable {
		 driver.get("D:\\Cucumber\\HotelBookingApp_152982\\src\\main\\webapp\\login.html");
	}

	@When("^I enter details and click Login button$")
	public void i_enter_details_and_click_Login_button() throws Throwable {
		loginPageBean.setUserName("capgemini");
		loginPageBean.setPassword("capg1234");
		loginPageBean.setLoginBtn();
	}

	@Then("^navigate to booking form page$")
	public void navigate_to_booking_form_page() throws Throwable {
		String pageHeading=loginPageBean.getPageTitle();
		
		assertTrue(pageHeading.equals("Hotel Booking Form"));
	}

	@When("^All the details are valid$")
	public void all_the_details_are_valid() throws Throwable {
		bookingPageBean.setBookingBtn();
		driver.switchTo().alert().accept();
		bookingPageBean.setFisrtName("Shravya");
		bookingPageBean.setBookingBtn();
		driver.switchTo().alert().accept();
		bookingPageBean.setLastName("Gunnala");
		bookingPageBean.setBookingBtn();
		driver.switchTo().alert().accept();
		bookingPageBean.setEmail("shravya@gmail.com");
		bookingPageBean.setBookingBtn();
		driver.switchTo().alert().accept();
		bookingPageBean.setMobile("8106025755");
		bookingPageBean.setBookingBtn();
		driver.switchTo().alert().accept();
		bookingPageBean.setAddress("Patancheru");
		bookingPageBean.setBookingBtn();
		driver.switchTo().alert().accept();
		bookingPageBean.setCity("Hyderabad");
		bookingPageBean.setBookingBtn();
		driver.switchTo().alert().accept();
		bookingPageBean.setState("Telangana");
		bookingPageBean.setBookingBtn();
		driver.switchTo().alert().accept();
		bookingPageBean.setNoOfGuest("5");
		bookingPageBean.setBookingBtn();
		driver.switchTo().alert().accept();
		bookingPageBean.setCardHolderName("Shravya");
		bookingPageBean.setBookingBtn();
		driver.switchTo().alert().accept();
		bookingPageBean.setCardNumber("1234567890987654");
		bookingPageBean.setBookingBtn();
		driver.switchTo().alert().accept();
		bookingPageBean.setCvv("123");
		bookingPageBean.setBookingBtn();
		driver.switchTo().alert().accept();
		bookingPageBean.setMonth("09");
		bookingPageBean.setBookingBtn();
		driver.switchTo().alert().accept();
		bookingPageBean.setYear("21");	
		bookingPageBean.setBookingBtn();
	}

	@Then("^navigate to success page$")
	public void navigate_to_success_page() throws Throwable {
		String url=driver.getCurrentUrl();
		assertTrue(url.equals("file:///D:/Cucumber/HotelBookingApp_152982/src/main/webapp/success.html"));
	}
	/*@After
	public void teardown()
	{
		driver.close();
	}*/



}
