package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPageBean {
	WebDriver driver;
	
	@FindBy(name="userName",how=How.NAME)
	private WebElement uName;
	
	@FindBy(name="userPwd",how=How.NAME)
	private WebElement uPwd;
	
	@FindBy(id="login",how=How.ID)
	private WebElement logIn;
	
	@FindBy(xpath="/html/body/div/h2")
	private WebElement pageheading;
	
	public LoginPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}


	public void setUserName(String username) {
		uName.sendKeys(username);
	}
	

	public void setPassword(String password) {
		uPwd.sendKeys(password);
	}

	public void setLoginBtn() {
		
		logIn.click();
	}
	
	public void navigateToBookingPage(String username,String password) {
		this.setUserName(username);
		this.setPassword(password);
		this.setLoginBtn();
	}

	public String getPageTitle() {
		return pageheading.getText();
	}
	
}
