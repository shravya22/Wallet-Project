package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class BookingPageBean {
	WebDriver driver;
	
	@FindBy(name="txtFN",how=How.NAME)
	private WebElement firstName;
	
	@FindBy(name="txtLN",how=How.NAME)
	private WebElement lastName;
	
	@FindBy(name="Email",how=How.NAME)
	private WebElement email;
	
	@FindBy(name="Phone",how=How.NAME)
	private WebElement mobile;
	
	@FindBy(name="Address",how=How.NAME)
	private WebElement address;
	
	@FindBy(name="city",how=How.NAME)
	private WebElement city;
	
	@FindBy(name="state",how=How.NAME)
	private WebElement state;
	
	@FindBy(name="persons",how=How.NAME)
	private WebElement noOfGuest;
	
	@FindBy(id="rooms",how=How.ID)
	private WebElement rooms;
	
	@FindBy(name="cardholdername",how=How.NAME)
	private WebElement cardHolderName;
	
	@FindBy(name="debit",how=How.NAME)
	private WebElement cardNo;
	
	@FindBy(name="cvv",how=How.NAME)
	private WebElement cvv;
	
	@FindBy(name="month",how=How.NAME)
	private WebElement mon;
	

	@FindBy(name="year",how=How.NAME)
	private WebElement yr;
	
	@FindBy(id="btnPayment",how=How.ID)
	private WebElement confirmBooking;
	
	public BookingPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}


	public void setFisrtName(String fNmae) {
		firstName.sendKeys(fNmae);
	}
	

	public void setLastName(String lName) {
		lastName.sendKeys(lName);
	}
	
	public void setEmail(String mail) {
		email.sendKeys(mail);
	}
	public void setMobile(String phnNo) {
		mobile.sendKeys(phnNo);
	}
	public void setAddress(String add) {
		address.sendKeys(add);
	}
	public void setCity(String City) {
		city.sendKeys(City);
	}
	public void setState(String State) {
		state.sendKeys(State);
	}
	public void setNoOfGuest(String guest) {
		noOfGuest.sendKeys(guest);
	}
	public void setRooms(String noOfRooms) {
		rooms.sendKeys(noOfRooms);
	}
	
	public void setCardHolderName(String name) {
		cardHolderName.sendKeys(name);
	}

	public void setCardNumber(String number) {
		cardNo.sendKeys(number);
	}
	public void setCvv(String Cvv) {
		cvv.sendKeys(Cvv);
	}
	public void setMonth(String month) {
		mon.sendKeys(month);
	}
	public void setYear(String year) {
		yr.sendKeys(year);
	}
	public void setBookingBtn() {
		
		confirmBooking.click();
	}
	
	public void navigateToBookingPage(String fNmae,String lName,String mail,String phnNo,String add,
			String City,String State,String guest,String noOfRooms,String name,String number,String Cvv,String month,String year) {
		this.setFisrtName(fNmae);
		this.setLastName(lName);
		this.setEmail(mail);
		
		this.setMobile(phnNo);
		this.setAddress(add);
		this.setCity(City);
		
		this.setState(State);
		this.setNoOfGuest(guest);
		this.setRooms(noOfRooms);
		
		this.setCardHolderName(name);
		this.setCardNumber(number);
		this.setCvv(Cvv);
		this.setMonth(month);
		this.setYear(year);
		
		this.setBookingBtn();
	}
	
}
