package org.cap.model;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {
	public static void main(String[] args) {
		EntityManagerFactory factory=
				Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=factory.createEntityManager();
		
		EntityTransaction transaction= entityManager.getTransaction();
		
		transaction.begin();
		
		Customer customer1=new Customer();
		customer1.setCustomerPwd("navy123");
		customer1.setFirstName("Navya");
		customer1.setLastName("Sree");
		customer1.setEmail("navya@gmail.com");
		customer1.setMobile("1234554321");
		customer1.setStatus("active");
		customer1.setLastLoginDate(new Date());
		
		Account account1=new Account();
		account1.setAccountNo(10006L);
		account1.setAccountType("savings");
		account1.setOpeningBalance(2000);
		account1.setOpeningDate(new Date());
		account1.setStatus("active");
		account1.setCustomer(customer1);
		
		Account account2=new Account();
		account2.setAccountNo(10007L);
		account2.setAccountType("current");
		account2.setOpeningBalance(2000);
		account2.setOpeningDate(new Date());
		account2.setStatus("active");
		account2.setCustomer(customer1);
		
		Customer customer2=new Customer();
		customer2.setCustomerPwd("raji456");
		customer2.setFirstName("Raji");
		customer2.setLastName("Pasupu");
		customer2.setEmail("raji@gmail.com");
		customer2.setMobile("4565434567");
		customer2.setStatus("active");
		customer2.setLastLoginDate(new Date());
		
		
		Account account3=new Account();
		account3.setAccountNo(10008L);
		account3.setAccountType("savings");
		account3.setOpeningBalance(2000);
		account3.setOpeningDate(new Date());
		account3.setStatus("active");
		account3.setCustomer(customer2);
		
		Account account4=new Account();
		account4.setAccountNo(10009L);
		account4.setAccountType("RD");
		account4.setOpeningBalance(2000);
		account4.setYears(3);
		account4.setOpeningDate(new Date());
		account4.setStatus("active");
		account4.setCustomer(customer2);
		
		Customer customer3=new Customer();
		customer3.setCustomerPwd("bhomi23");
		customer3.setFirstName("Bhoomi");
		customer3.setLastName("Ram");
		customer3.setEmail("bhoomi@gmail.com");
		customer3.setMobile("3456789876");
		customer3.setStatus("active");
		customer3.setLastLoginDate(new Date());
		
		
		Account account5=new Account();
		account5.setAccountNo(10010L);
		account5.setAccountType("FD");
		account5.setYears(3);
		account5.setOpeningBalance(2000);
		account5.setOpeningDate(new Date());
		account5.setStatus("active");
		account5.setCustomer(customer3);
		
		/*Transaction transaction1=new Transaction();
		transaction1.setCustomer(customer1);
		transaction1.setFromAccount(account1);
		transaction1.setToAccount(account4);
		transaction1.setAmount(1000);
		transaction1.setTransactionType("debit");
		transaction1.setDescription("Mobile Recharge");
		transaction1.setStatus("success");
		transaction1.setTransactionDate(new Date());
		
		
		Transaction transaction2=new Transaction();
		transaction2.setCustomer(customer2);
		transaction2.setFromAccount(account3);
		transaction2.setToAccount(account2);
		transaction2.setAmount(1000);
		transaction2.setTransactionType("credit");
		transaction2.setDescription("Bill Payment");
		transaction2.setStatus("success");
		transaction2.setTransactionDate(new Date());*/
		
		entityManager.persist(customer1);
		entityManager.persist(customer2);
		entityManager.persist(customer3);
		entityManager.persist(account1);
		entityManager.persist(account2);
		entityManager.persist(account3);
		entityManager.persist(account4);
		entityManager.persist(account5);
		/*entityManager.persist(transaction1);
		entityManager.persist(transaction2);*/
		transaction.commit();

	}

}
