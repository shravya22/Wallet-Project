package org.cap.walletdao;

import java.util.List;
import java.util.Map;

import org.cap.model.Account;

public interface AccountDao {

	public void createAccount(Account account);

	public Map<Account, Double> getAmout(String str, int custId);

	public List<Account> getAllAccounts(int custId);

	public List<Account> getremAccounts(int custId);


	public Account findAccount(int fromAccId);
}
