package com.wallet.service;

import java.util.HashMap;

import com.wallet.bean.Transaction;
import com.wallet.bean.WalletDetails;
import com.wallet.dao.WalletDAO;
import com.wallet.dao.WalletDAOImp;
import com.wallet.exception.WalletException;

public class WalletServiceImp implements WalletService {

	WalletDAO wdao=new WalletDAOImp();
	@Override
	public boolean validateDetails(WalletDetails wd)throws WalletException {
		// TODO Auto-generated method stub
		if(validateAccType(wd.getAccttype())&&validateName(wd.getName())&&
				validateMobile(wd.getMobile())&&validateEmail(wd.getEmail())&&
				validateAddress(wd.getAddress())&&validateAadhar(wd.getAadhar())&&
				validateAge(wd.getAge())&&validatePin(wd.getPin())) {
			return true;
		}
		return false;
	}

	

	private boolean validatePin(String pin) throws WalletException {
		// TODO Auto-generated method stub
		if(pin.isEmpty()|| pin==null) {
			throw new  WalletException("Pin number is mandatory");
			
		}
		else {
			if(!pin.matches("\\d{4}")){
				throw new  WalletException("Pin must contain only 4 digits");
				
			}
		}
		return true;
	}



	private boolean validateAge(String age) throws WalletException {
		// TODO Auto-generated method stub
		if(age.isEmpty() || age==null) {
			throw new WalletException("Age cannot be empty");
		}
		else if(age.matches("[A-Za-z]{1,}")) {
				throw new WalletException("Enter correct age in numbers");
			}
		else
		{
			if(Integer.parseInt(age)<18||Integer.parseInt(age)>=100)
				throw new WalletException("Age is invalid, age should be between 18 and 100");
		
	}
		return true;
	}



	private boolean validateAadhar(String aadhar) throws WalletException {
		// TODO Auto-generated method stub
			if(aadhar.isEmpty()|| aadhar==null) {
				throw new  WalletException("Aadhar number is manadatory");
				
			}
			else {
				if(!aadhar.matches("\\d{12}")){
					throw new  WalletException("Aadhar number should contain only 12 digits");
					
				}
			}
			return true;
	}

	private boolean validateEmail(String email) throws WalletException {
		// TODO Auto-generated method stub
		if(!email.matches("[A-Za-z0-9_]+@[a-z]+\\.com")) {
			throw new WalletException("please enter a valid email id");
			
			
		}
		return true;
	}

	private boolean validateAddress(String address) throws WalletException {
		// TODO Auto-generated method stub
		if(address.isEmpty() || address==null) {
			throw new WalletException("Enter your current address");
		}
		else {
			if(!address.matches("[A-Z][A-Za-z]{2,}")) {
				throw new WalletException("Address should start with a capital letter followed by a min of 2 alphabets");
			}
		}
		return true;
	}

	private boolean validateMobile(String mobile) throws WalletException {
		// TODO Auto-generated method stub
		if(mobile.isEmpty()|| mobile==null) {
			throw new WalletException("Mobile number is manadatory");
			
		}
		else {
			if(!mobile.matches("\\d{10}")){
				throw new WalletException("Mobile number should contain only 10 digits");
				
			}
		}
		return true;
	}

	private boolean validateName(String name) throws WalletException {
		// TODO Auto-generated method stub
		if(name.isEmpty() || name==null) {
			throw new WalletException("Name cannot be empty");
		}
		else {
			if(!name.matches("[A-Z][A-Za-z]{2,}")) {
				throw new WalletException("Name should start with a capital letter followed by a min of 2 alphabets");
			}
		}
		return true;
	}

	private boolean validateAccType(String accttype) throws WalletException {
		// TODO Auto-generated method stub
		if(accttype.isEmpty() || accttype==null) {
			throw new WalletException("Account type cannot be empty");
		}
		else if(!(accttype.equalsIgnoreCase("Savings")||accttype.equalsIgnoreCase("Salary")||accttype.equalsIgnoreCase("Current")))
		{
			throw new WalletException("Account type should be Savings or Salary or Current");
		}
		return true;
	}

	@Override
	public long createAcc(WalletDetails wd)throws WalletException {
		// TODO Auto-generated method stub
		return wdao.createAcc(wd);
	}



	@Override
	public boolean validate(long acno,String p) throws WalletException {
		// TODO Auto-generated method stub
		return wdao.validate(acno,p);
	}



	@Override
	public double showBal(long acno) throws WalletException {
		// TODO Auto-generated method stub
		return wdao.showBal(acno);
	}

	@Override
	public double deposit(long acno, double amt) throws WalletException {
		// TODO Auto-generated method stub
		return wdao.deposit(acno,amt);
	}



	@Override
	public double withdraw(long acno, double amt) throws WalletException {
		// TODO Auto-generated method stub
		return wdao.withdraw(acno,amt);
	}



	@Override
	public double fundTransfer(long acno, long acno1, double amt) throws WalletException {
		// TODO Auto-generated method stub
		return wdao.fundTransfer(acno, acno1,amt);
	}



	@Override
	public boolean printTransactions(long acno) throws WalletException {
		// TODO Auto-generated method stub
		return wdao.printTransactions(acno);
	}





	

}
