package com.wallet.db;

import java.util.HashMap;

import com.wallet.bean.Transaction;
import com.wallet.bean.WalletDetails;


public class WalletDB {
	private static HashMap<Long,WalletDetails>
	WalletMap=new HashMap<Long,WalletDetails>();
	private static HashMap<Integer,Transaction>
	TransactionMap=new HashMap<Integer,Transaction>();
	static {
		WalletMap.put(405109802301l,new WalletDetails(405109802301l,"Savings","Sweety","1234567890","sweety@gmail.com","Hyderabad","123443212345",50000.00,"23","2234"));
		WalletMap.put(405109802302l,new WalletDetails(405109802302l,"Salary","Siri","1234554321","siri@gmail.com","Bangalore","654789092345",67889.50,"22","4567"));
		WalletMap.put(405109802303l,new WalletDetails(405109802303l,"Current","Hari","6789009876","hari@gmail.com","Hyderabad","408834562343",34545.00,"30","3434"));
		WalletMap.put(405109802304l,new WalletDetails(405109802304l,"Savings","Abhi","4567887654","abhi@gmail.com","Chennai","456723453232",56000.00,"26","2345"));
		WalletMap.put(405109802305l,new WalletDetails(405109802305l,"Savings","Siri","1234554321","siri@gmail.com","Bangalore","456789012233",6755.67,"22","6787"));
		WalletMap.put(405109802306l,new WalletDetails(405109802306l,"Salary","Janu","2345665432","janu@gmail.com","Hyderabad","345665432345",5678.90,"28","4554"));
	}
	public static HashMap<Long, WalletDetails> getWalletMap() {
		return WalletMap;
	}
	public static HashMap<Integer,Transaction> getTransactionMap()
	{
		return TransactionMap;
	}
}
