package com.wallet.bean;

public class WalletDetails {
	private long acctNo;
	private String accttype;
	private String name;
	private String mobile;
	private String email;
	private String address;
	private String aadhar;
	private double balance;
	private String age;
	private String pin;
	
	public WalletDetails(long acctNo, String accttype, String name, String mobile, String email, String address,
			String aadhar, double balance, String age,String pin) {
		super();
		this.acctNo = acctNo;
		this.accttype = accttype;
		this.name = name;
		this.mobile = mobile;
		this.email = email;
		this.address = address;
		this.aadhar = aadhar;
		this.balance=balance;
		this.age=age;
		this.pin=pin;
	}
	public WalletDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	public long getAcctNo() {
		return acctNo;
	}
	public void setAcctNo(long acctNo) {
		this.acctNo = acctNo;
	}
	public String getAccttype() {
		return accttype;
	}
	public void setAccttype(String accttype) {
		this.accttype = accttype;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAadhar() {
		return aadhar;
	}
	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	
}
