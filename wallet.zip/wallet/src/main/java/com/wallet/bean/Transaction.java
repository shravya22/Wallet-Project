package com.wallet.bean;

import java.time.LocalDate;


public class Transaction {
	
	private int transId;
	private long acno;
	private String transtype;
	private LocalDate date;
	private double amount;
	public String getTranstype() {
		return transtype;
	}
	public void setTranstype(String transtype) {
		this.transtype = transtype;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public long getAcno() {
		return acno;
	}
	public void setAcno(long acno) {
		this.acno = acno;
	}
	public Transaction(long acno,String transtype, LocalDate date, double amount) {
		super();
		
		this.acno=acno;
		this.transtype = transtype;
		this.date = date;
		this.amount = amount;
	}
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Account Number : " + acno +"\nTransaction type : " + transtype + "\nDate of tranfer : " + date + "\nAmount : " + amount;
	}
	
	
}
