package com.wallet.dao.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.wallet.bean.Transaction;
import com.wallet.bean.WalletDetails;
import com.wallet.dao.WalletDAO;
import com.wallet.dao.WalletDAOImp;
import com.wallet.exception.WalletException;

public class WalletDAOImpTest {
	WalletDAO wdao=new WalletDAOImp();
	WalletDetails wd= new WalletDetails();
	@Test
	public void testCreateAcc() {
		wd.setAcctNo(405109802301l);
		wd.setAccttype("Savings");
		wd.setName("Sweety");
		wd.setMobile("1234567890");
		wd.setEmail("sweety@gmail.com");
		wd.setAddress("Hyderabad");
		wd.setAadhar("123443212345");
		wd.setBalance(50000.00);
		wd.setAge("23");
		wd.setPin("2234");
		try {
			long acno=wdao.createAcc(wd);
			
			assertEquals(acno,405109802307l);
			
			
		}catch (WalletException e)
		{
			e.printStackTrace();
		}
	}

	@Test
	public void testValidate() {
		try {
		assertEquals(true,wdao.validate(405109802301l, "2234"));
		}catch (WalletException e)
		{
			e.printStackTrace();
		}
		
	}

	@Test
	public void testShowBal() {
		try {
			double bal=wdao.showBal(405109802301l);
			assertNotNull(bal);
		}catch (WalletException e)
		{
			e.printStackTrace();		}
	}

	@Test
	public void testDeposit() {

try {
	assertEquals(true,wdao.deposit(405109802307l,5000.00));
}catch (WalletException e)
{
	e.printStackTrace();
}
	}

	@Test
	public void testWithdraw() {
		try {
			assertEquals(true,wdao.withdraw(405109802307l,5000.00));
		}catch (WalletException e)
		{
			e.printStackTrace();
		}
	}

	@Test
	public void testFundTransfer() {
        try {
            assertEquals(true, wdao.fundTransfer(405109802301l,405109802307l, 2000));
     } catch (WalletException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
     }

	}

	@Test
	public void testPrintTransactions() {
		try {
		boolean b = wdao.printTransactions(405109802307l);
        assertFalse(b);
 } catch (WalletException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
 }

	}

}
