package com.wallet.dao.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.wallet.bean.WalletDetails;
import com.wallet.dao.WalletDAO;
import com.wallet.dao.WalletDAOImp;
import com.wallet.db.WalletDB;
import com.wallet.exception.WalletException;

public class WalletDAOImpTest {
	WalletDAO wdao=new WalletDAOImp();
	WalletDetails wd= new WalletDetails();
	WalletDB db=new WalletDB();
	@Test
	public void testCreateAcc() {
		assertEquals(6,db.getWalletMap().size());
		wd.setAcctNo(405109802307l);
		wd.setAccttype("Current");
		wd.setName("Lucky");
		wd.setMobile("5674356789");
		wd.setEmail("lucky@gmail.com");
		wd.setAddress("Mumbai");
		wd.setAadhar("123123123123");
		wd.setBalance(5000.00);
		wd.setAge("28");
		wd.setPin("8844");
		try {
			wdao.createAcc(wd);
			assertEquals(7,db.getWalletMap().size());
		}catch (WalletException e)
		{
			e.printStackTrace();
		}
	}

	@Test
	public void testValidate() {
		try {
			assertEquals(true,wdao.validate(405109802301l, "2234"));
		}catch (WalletException e)
		{
			e.printStackTrace();
		}
		
	}

	@Test
	public void testShowBal() {
		try {
			assertEquals(Double.toString(50000.0), Double.toString(wdao.showBal(405109802301l)));
		}catch (WalletException e)
		{
			e.printStackTrace();		}
	}

	@Test
	public void testDeposit() {

try {
	assertEquals(Double.toString(60000.0),Double.toString(wdao.deposit(405109802304l, 4000.0)));
}catch (WalletException e)
{
	e.printStackTrace();
}
	}

	@Test
	public void testWithdraw() {
		try {
			assertEquals(Double.toString(6000.0),Double.toString(wdao.withdraw(405109802305l, 755.67)));
		}catch (WalletException e)
		{
			e.printStackTrace();
		}
	}

	@Test
	public void testFundTransfer() {
        try {
            assertEquals(Double.toString(4678.90),Double.toString(wdao.fundTransfer(405109802306l, 405109802303l, 1000.0)));
     } catch (WalletException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
     }

	}

	@Test
	public void testPrintTransactions() {
		try {
		boolean b = wdao.printTransactions(405109802301l);
       assertEquals(false,b);
 } catch (WalletException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
 }

	}

}
