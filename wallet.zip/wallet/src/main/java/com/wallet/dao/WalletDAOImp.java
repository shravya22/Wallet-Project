package com.wallet.dao;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Optional;

import com.wallet.bean.Transaction;
import com.wallet.bean.WalletDetails;
import com.wallet.db.WalletDB;
import com.wallet.exception.WalletException;

public class WalletDAOImp implements WalletDAO{
	static HashMap<Long,WalletDetails> WalletMap=WalletDB.getWalletMap();
	static HashMap<Integer,Transaction> TransactionMap=WalletDB.getTransactionMap();
	Transaction t=new Transaction();
	int transId=0;
	@Override
	public long createAcc(WalletDetails wd) throws WalletException {
		// TODO Auto-generated method stub
		try {
			if(WalletMap.size()==0) {
				wd.setAcctNo(405109802301l);
			}
			else {
				Optional<Long> id=WalletMap.keySet().stream().max(new Comparator<Long>() {
				@Override
				public int compare(Long x,Long y)
				{
					return x>y?1:x<y?-1:0;
				}
			});
			long reqid=id.get()+1;
			wd.setAcctNo(reqid);
			}
			
		 WalletMap.put(wd.getAcctNo(),wd);
			return wd.getAcctNo();
		}catch(Exception e)
		{
			throw new WalletException(e.getMessage());
		}
	}
	@Override
	public boolean validate(long acno,String p) throws WalletException {
		// TODO Auto-generated method stub
		WalletDetails wd=WalletMap.get(acno);
		try {
			if(wd==null)
				throw new WalletException("Account number is invalid");
			if(wd.getPin().equalsIgnoreCase(p))
				return true;
			else
				throw new WalletException("Enter correct pin");
		}catch(Exception e)
		{
			throw new WalletException(e.getMessage());
		}
	}
	@Override
	public double showBal(long acno) throws WalletException {
		// TODO Auto-generated method stub
		try {
		WalletDetails wd=WalletMap.get(acno);
		return wd.getBalance();
		}catch(Exception e)
		{
			throw new WalletException(e.getMessage());
		}
	}
	@Override
	public double deposit(long acno, double amt) throws WalletException {
		// TODO Auto-generated method stub
		try {
		WalletDetails wd=WalletMap.get(acno);
		wd.setBalance(wd.getBalance()+amt);
		
		transId++;
		TransactionMap.put(transId,new Transaction(acno, "Deposit", LocalDate.now(), amt));
		
		return wd.getBalance();
	}catch(Exception e)
		{
		throw new WalletException(e.getMessage());
	}
		}
	@Override
	public double withdraw(long acno, double amt) throws WalletException {
		// TODO Auto-generated method stub
		try {
		WalletDetails wd=WalletMap.get(acno);
		if(wd.getBalance()>amt) {
		wd.setBalance(wd.getBalance()-amt);
				transId++;
		TransactionMap.put(transId,new Transaction(acno, "Withdraw", LocalDate.now(), amt));
		return wd.getBalance();
		}
		else
			throw new WalletException("Insufficient balance in your account");
		}catch(Exception e)
		{
			throw new WalletException(e.getMessage());
		}	
	}
	@Override
	public double fundTransfer(long acno, long acno1, double amt) throws WalletException {
		// TODO Auto-generated method stub
		try {
			WalletDetails wd=WalletMap.get(acno);
			WalletDetails wd1=WalletMap.get(acno1);
			if(wd==null) throw new WalletException("Enter your account number correctly");
			if(wd1==null) throw new WalletException("Enter the correct account number to which you want to transfer");
			if(wd==wd1) throw new WalletException("Both the account numbers cannot be same");
			else
			{
				double a=wd.getBalance();
				if(amt<=0)
				{
					throw new WalletException("Enter correct amount greater than 0");
				}
				else if(a<amt)
				{
					throw new WalletException("Insufficient balance in your account");
				}
				else {
					wd.setBalance(wd.getBalance()-amt);
					wd1.setBalance(wd1.getBalance()+amt);
										transId++;
					TransactionMap.put(transId,new Transaction(acno, "Fund Transfer", LocalDate.now(), amt));
					return wd.getBalance();
				}
				
			}
			
	}catch(Exception e)
		{
		throw new WalletException(e.getMessage());
	}	

}
	@Override
	public boolean printTransactions(long acno) throws WalletException {
		// TODO Auto-generated method stub
		try {
		for(int key=1;key<=TransactionMap.size();key++)
		{
			Transaction trans=TransactionMap.get(key);
			if(trans.getAcno()==acno)
			{
				System.out.println(trans);
			}
		}
		if(TransactionMap.size()==0)
			throw new WalletException("No transactions till now");
		
	}catch(Exception e)
		{
		throw new WalletException(e.getMessage());
	}	
		return false;
		
		
}
}
