package org.cap.walletdao;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.cap.model.Transaction;
import org.cap.walletservice.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("transDao")
@Transactional
public class TransactionDaoImp implements TransactionDao {
	@PersistenceContext
	private EntityManager entitymanager;
	@Autowired
	private LoginService loginService;
	@Override
	public void createTransaction(Transaction transaction) {
		entitymanager.persist(transaction);
		
	}
	@Override
	public List<Transaction> printTransactions(Integer customerId) {
		Query query= entitymanager.createQuery("from Transaction transaction where transaction.customer.customerId=:cust");
		query.setParameter("cust", customerId);
			List<Transaction> transaction= query.getResultList();
		for (Transaction trans : transaction) {
			System.out.println(trans);
		}
		return transaction;
	}
	@Override
	public void fundTransfer(Transaction transfer) {
		// TODO Auto-generated method stub
		entitymanager.persist(transfer);
		int custId=getCustId(transfer.getToAccount().getAccountId());
		Transaction transaction=new Transaction();
		transaction.setCustomer(loginService.findCustomer(custId));
		transaction.setTransactionDate(new Date());
		transaction.setTransactionType("credit");
		transaction.setFromAccount(transfer.getFromAccount());
		transaction.setToAccount(transfer.getToAccount());
		transaction.setAmount(transfer.getAmount());
		transaction.setDescription(transfer.getDescription());
		transaction.setStatus("Success");
		entitymanager.persist(transaction);
	}
	@Transactional(readOnly=true)
	private int getCustId(int accId) {
		Query query= entitymanager.createQuery("select acct.customer.customerId from Account acct where acct.accountId=:accId");
		query.setParameter("accId", accId);
		List<Integer> id=query.getResultList();
		return id.get(0);
	}
	@Override
	public List<Transaction> printDatedTransactions(Integer customerId, Date d1, Date d2) {
		Calendar cal = Calendar.getInstance();
		 cal.setTime(d2);
				    cal.add(Calendar.DATE, 1); //minus number would decrement the days
				    Date d3= cal.getTime(); 
		Query query= entitymanager.createQuery("from Transaction tx where tx.customer.customerId=? and transactionDate between ? and ?");
		query.setParameter(0, customerId);
		query.setParameter(1,d1);
		query.setParameter(2,d3);
		
		List<Transaction> transactions= query.getResultList();
		return transactions;
	}

}
