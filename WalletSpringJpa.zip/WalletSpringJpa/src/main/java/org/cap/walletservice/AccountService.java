package org.cap.walletservice;

import java.util.List;

import org.cap.model.Account;

public interface AccountService {

	public void createAccount(Account account);

	public List<Account> getAccountWithBal(int custId);

	public List<Account> getAllAccounts(int custId);

	public List<Account> getremAccounts(int custId);

	public Account findAccount(int fromAccId);



	
}
