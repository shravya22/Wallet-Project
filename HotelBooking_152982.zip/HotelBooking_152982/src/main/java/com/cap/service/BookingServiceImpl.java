package com.cap.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.IBookingDao;
import com.cap.model.HotelDetails;
@Service("bookingService")
public class BookingServiceImpl implements IBookingService{
	@Autowired
	private IBookingDao bookingDao; 
	@Override
	public List<HotelDetails> displayDetails() {
		// TODO Auto-generated method stub
		return bookingDao.displayDetails();
	}
	@Override
	public HotelDetails getHotelByName(String name) {
		// TODO Auto-generated method stub
		return bookingDao.getHotelByName(name);
	}

}
