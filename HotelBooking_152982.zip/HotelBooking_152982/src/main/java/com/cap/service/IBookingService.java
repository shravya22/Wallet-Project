package com.cap.service;

import java.util.List;

import com.cap.model.HotelDetails;

public interface IBookingService {

	public List<HotelDetails> displayDetails();

	public HotelDetails getHotelByName(String name);

}
