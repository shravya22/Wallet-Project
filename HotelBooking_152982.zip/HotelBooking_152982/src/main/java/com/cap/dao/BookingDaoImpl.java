package com.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cap.model.HotelDetails;
@Repository("bookingDao")
public class BookingDaoImpl implements IBookingDao {
	@PersistenceContext
	private EntityManager entityManager;
	@Override
	@Transactional
	public List<HotelDetails> displayDetails() {
		/**
		 * Method Name : displayDetails
		 * Parameters :Nil
		 * Return type : List of HotelDetails
		 * Purpose :Retrieves all the data from the underlying data store
		 * Author : Shravya Gunnala
		 * Date of Creation : 28th July 2018
		 * Last Modified date : 28th July 2018
		 */ 
		  
		List<HotelDetails> details= entityManager.createQuery("from HotelDetails").getResultList();
		return details;
	}
	@Override
	@Transactional
	public HotelDetails getHotelByName(String name) {
		
		/**
		 * Method Name : displayDetails
		 * Parameters : name
		 * Return type : link with hotel name for booking 
		 * Purpose : for booking rooms in hotel
		 * Author : Shravya Gunnala
		 * Date of Creation : 28th July 2018
		 * Last Modified date : 28th July 2018
		 */ 
		Query query= entityManager
				.createQuery("from HotelDetails where name=:hotelname");
			
			query.setParameter("hotelname", name);
			
			
			List<HotelDetails> details= query.getResultList();
			
			
			return details.get(0);
	}

}
