package com.cap.dao;

import java.util.List;

import com.cap.model.HotelDetails;

public interface IBookingDao {

	public List<HotelDetails> displayDetails();

	public HotelDetails getHotelByName(String name);

}
