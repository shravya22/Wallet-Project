package com.cap.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class HotelDetails {
	@Id
private int id;
private String name;
private String rating;
private double rate;
private int availablerooms;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getRating() {
	return rating;
}
public void setRating(String rating) {
	this.rating = rating;
}
public double getRate() {
	return rate;
}
public void setRate(double rate) {
	this.rate = rate;
}
public int getAvailablerooms() {
	return availablerooms;
}
public void setAvailablerooms(int availablerooms) {
	this.availablerooms = availablerooms;
}
@Override
public String toString() {
	return "HotelDetails [id=" + id + ", name=" + name + ", rating=" + rating + ", rate=" + rate + ", availablerooms="
			+ availablerooms + "]";
}
public HotelDetails(int id, String name, String rating, double rate, int availablerooms) {
	super();
	this.id = id;
	this.name = name;
	this.rating = rating;
	this.rate = rate;
	this.availablerooms = availablerooms;
}
public HotelDetails() {}
}
