package com.cap.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cap.model.HotelDetails;
import com.cap.service.IBookingService;
@Controller
public class BookingController {
	@Autowired
	private IBookingService bookingService;
	@RequestMapping("/")
	public String showHotels(ModelMap map) {
		List<HotelDetails> details=bookingService.displayDetails();
		
		map.put("details", details);
		map.put("detail", new HotelDetails());
		return "HotelDetails";
	}
	@RequestMapping("/booking/{name}")
	public String showBooking(@PathVariable("name") String name,ModelMap map)
	{
		HotelDetails hotel=bookingService.getHotelByName(name);
		map.put("hotel", hotel);
		return "HotelBooking";
	}
	@RequestMapping("booking/bookingDone/{name}")
	public ModelAndView showBookingDone(@PathVariable("name") String name)
	{
		return new ModelAndView("BookingConfirmation","name",name);
	}
}
