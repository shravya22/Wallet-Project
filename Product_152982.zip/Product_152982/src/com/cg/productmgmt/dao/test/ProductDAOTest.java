package com.cg.productmgmt.dao.test;

import static org.junit.Assert.*;

import java.util.Map;

import org.junit.Test;

import com.cg.productmgmt.dao.IProductDAO;
import com.cg.productmgmt.dao.ProductDAO;
import com.cg.productmgmt.exception.ProductException;


public class ProductDAOTest {
	IProductDAO pdao=new ProductDAO();
	@Test
	public void testUpdateProducts() {
		try {
			int product=pdao.UpdateProducts("electronics", 10);
			assertEquals(1,product);
		}
		catch(ProductException e){
			e.printStackTrace();
		}
	}

	@Test
	public void testGetProductDetails() {
		try {
			Map<String,Integer>p=pdao.getProductDetails();
			assertEquals(7,pdao.getProductDetails().size());
		}
		catch(ProductException e)
		{
			e.printStackTrace();
		}
	}

}
