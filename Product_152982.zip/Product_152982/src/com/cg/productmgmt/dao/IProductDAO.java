package com.cg.productmgmt.dao;

import java.util.Map;

import com.cg.productmgmt.exception.ProductException;

public interface IProductDAO {

	int UpdateProducts(String Category, int hike) throws ProductException;
	Map<String, Integer> getProductDetails() throws ProductException;
	Map<String, String> getDetails() throws ProductException;

}
