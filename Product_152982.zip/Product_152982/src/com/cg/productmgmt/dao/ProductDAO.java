package com.cg.productmgmt.dao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.cg.productmgmt.exception.ProductException;

public class ProductDAO implements IProductDAO {
	static Map<String,String> ProductDetails;
	static Map<String,Integer> SalesDetails;
	static {
		ProductDetails=new HashMap<>();
		ProductDetails.put("lux", "soap");
		ProductDetails.put("colgate", "paste");
		ProductDetails.put("pears", "soap");
		ProductDetails.put("sony", "electronics");
		ProductDetails.put("samsung", "electronics");
		ProductDetails.put("facepack", "cosmatics");
		ProductDetails.put("facecream", "cosmatics");
		
		SalesDetails=new HashMap<>();
		SalesDetails.put("lux", 100);
		SalesDetails.put("colgate", 50);
		SalesDetails.put("pears", 70);
		SalesDetails.put("sony", 10000);
		SalesDetails.put("samsung", 23000);
		SalesDetails.put("facepack", 100);
		SalesDetails.put("facecream", 60);
	}
	@Override
	public int UpdateProducts(String Category, int hike) throws ProductException {
		/**
		 * Method Name: UpdateProducts
		 * Return type: int
		 * Parameters: Category,hike
		 * Purpose: To update the product price
		 * Author: Shravya
		 * Date of creation: 4th July 2018
		 * Last Date of Modification: 4th July 2018
		 */
		// TODO Auto-generated method stub
		Set<String> products=new HashSet<String>();
		Set<String> keys=ProductDetails.keySet();
		String value=null;
		int newprice=0;
		int update=0;
		boolean isupdate=false;
		for(String key: keys)
		{
			value=ProductDetails.get(key);
			if(value.equals(Category))
			{
				products.add(key);
			}
				
		}
		Set<String> keysales=ProductDetails.keySet();
		for(String sale:keysales) {
			if(products.contains(sale)) 
			{
				newprice=SalesDetails.get(sale);
				newprice=newprice+hike;
				SalesDetails.put(sale, newprice);
				update=1;
			}
		}
		return update;
	}

	@Override
	public Map<String, Integer> getProductDetails() throws ProductException {
		/**
		 * Method Name: getProductDetails
		 * Return type: map
		 * Parameters: nil
		 * Purpose: To display the product list
		 * Author: Shravya
		 * Date of creation: 4th July 2018
		 * Last Date of Modification: 4th July 2018
		 */
		// TODO Auto-generated method stub
		return SalesDetails;
	}

	@Override
	public Map<String, String> getDetails() throws ProductException {
		// TODO Auto-generated method stub
		return ProductDetails;
	}

}
