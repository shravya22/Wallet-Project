package com.cg.productmgmt.service;

import java.util.Map;

import com.cg.productmgmt.exception.ProductException;

public interface IProductService {

	Map<String, Integer> getProductDetails() throws ProductException;
	int UpdateProducts(String Category, int hike) throws ProductException;

}
