package com.cg.productmgmt.service;

import java.util.Map;

import com.cg.productmgmt.dao.IProductDAO;
import com.cg.productmgmt.dao.ProductDAO;
import com.cg.productmgmt.exception.ProductException;

public class ProductService implements IProductService {
	IProductDAO pdao=new ProductDAO();
	@Override
	public Map<String, Integer> getProductDetails() throws ProductException {
		// TODO Auto-generated method stub
		
		return pdao.getProductDetails();
	}

	@Override
	public int UpdateProducts(String Category, int hike) throws ProductException {
		// TODO Auto-generated method stub
		if(validateCategory(Category)&&validateHike(hike))
		{
			return pdao.UpdateProducts(Category,hike);
		}
		return 0;
	}

	private boolean validateCategory(String Category) throws ProductException {
		// TODO Auto-generated method stub
		try {
			if(pdao.getDetails().containsValue(Category))
				return true;
			else
				throw new ProductException("This category is not present in the list");
		}catch(ProductException e)
		{
			throw new ProductException("This category is not present in the list");
		}
	}
	private boolean validateHike(int hike) throws ProductException {
		// TODO Auto-generated method stub
		if(hike>0)
			return true;
		else
			throw new ProductException("Hike should be greater than 0");
	}


}
