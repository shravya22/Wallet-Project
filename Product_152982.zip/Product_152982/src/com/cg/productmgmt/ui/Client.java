package com.cg.productmgmt.ui;

import java.util.Map;
import java.util.Scanner;

import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.IProductService;
import com.cg.productmgmt.service.ProductService;

public class Client {
	Scanner scan=new Scanner(System.in);
	IProductService ps=new ProductService();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Client c=new Client();
		String choice=null;
		while(true)
		{
			System.out.println("----------Product------------");
			System.out.println("1)Update Product Price\n2)Display Product List\n3)Exit");
			choice=c.scan.nextLine();
			switch(choice)
			{
			case "1":
				c.UpdateProducts();
				break;
			case "2":
				c.getProductDetails();
				break;
			case "3":
				System.exit(0);
				break;
			}
		}
	}
	public void getProductDetails() {
		// TODO Auto-generated method stub
		try {
			Map<String,Integer>ProductMap;
			ProductMap=ps.getProductDetails();
			System.out.println(ProductMap);
		}
		catch(ProductException e)
		{
			System.err.println("Error occurred "+e.getMessage());
		}
	}
	public void UpdateProducts() {
		// TODO Auto-generated method stub
		try {
			System.out.println("Enter the Product Category : ");
			String Category=scan.nextLine();
			System.out.println("Enter hike Rate");
			int hike=Integer.parseInt(scan.nextLine());
			int ret=ps.UpdateProducts(Category,hike);
			if(ret==1)
			{
				System.out.println("Successfully hiked prices for "+Category+" by "+hike);
			}
		}
		catch(ProductException e)
		{
			System.err.println("Error occurred "+e.getMessage());
		}
	}

}
