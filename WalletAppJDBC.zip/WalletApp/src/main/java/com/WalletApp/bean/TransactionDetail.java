package com.WalletApp.bean;


import java.sql.Date;


public class TransactionDetail {
	
	private int transId;
	private long acno;
	private String transtype;
	private Date transDate;
	private double amount;
	public String getTranstype() {
		return transtype;
	}
	public void setTranstype(String transtype) {
		this.transtype = transtype;
	}
	public Date getTransDate() {
		return transDate;
	}
	public void setTransDate(Date date) {
		this.transDate = date;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public long getAcno() {
		return acno;
	}
	public void setAcno(long acno) {
		this.acno = acno;
	}
	public TransactionDetail(int transId,long acno,String transtype, Date transDate, double amount) {
		super();
		this.transId=transId;
		this.acno=acno;
		this.transtype = transtype;
		this.transDate = transDate;
		this.amount = amount;
	}
	public TransactionDetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Transaction Id : "+transId+"\nAccount Number : " + acno +"\nTransaction type : " + transtype + "\nDate of tranfer : " + transDate + "\nAmount : " + amount;
	}
	
	
}

