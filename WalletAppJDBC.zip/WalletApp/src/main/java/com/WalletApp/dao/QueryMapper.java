package com.WalletApp.dao;


public interface QueryMapper {
	public static final String INSERT_QUERY="INSERT INTO WalletDetails VALUES(acctNo_sequence.NEXTVAL,?,?,?,?,?,?,?,?,?)";
	public static final String ACCTNO_QUERY_SEQUENCE="SELECT acctNo_sequence.CURRVAL FROM DUAL";
	public static final String SHOWBAL_QUERY="SELECT balance FROM WalletDetails where acctNo=?";
	public static final String VALIDATE_QUERY="select acctNo from WalletDetails where acctNo=? AND pin=?";
	public static final String SELECT_BALANCE_QUERY="select balance from WalletDetails where acctNo=?";
	public static final String DEPOSIT_QUERY="update WalletDetails set balance=balance+? where acctNo=?";
	public static final String WITHDRAW_QUERY="update WalletDetails set balance=balance-? where acctNo=?";
	public static final String CHECK_QUERY="select acctNo from WalletDetails where acctNo=?";
	public static final String INSERT_TRANS_QUERY="INSERT INTO TransactionDetail VALUES(transId_sequence.NEXTVAL,?,?,?,?)";
	public static final String DATE_QUERY="select sysdate from dual";
	public static final String TRANS_QUERY_SEQUENCE="SELECT transId_sequence.CURRVAL FROM DUAL";
	public static final String TRANS_QUERY="select * from TransactionDetail  where acno=?";
	public static final String COUNT_QUERY="select count(*) from WalletDetails";
}
