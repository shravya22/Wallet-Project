package com.WalletApp.exception;

public class WalletException extends Exception{
	private static final long serialVersionUID = 726264577455921591L;

	public WalletException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public WalletException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
