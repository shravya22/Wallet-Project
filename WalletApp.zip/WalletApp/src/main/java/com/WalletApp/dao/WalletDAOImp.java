package com.WalletApp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.WalletApp.bean.TransactionDetail;
import com.WalletApp.bean.WalletDetails;

import com.WalletApp.exception.WalletException;
import com.WalletApp.util.DBConnection;



public class WalletDAOImp implements WalletDAO{

	int transId=0;
	Logger logger=Logger.getRootLogger();
	WalletDetails wd= new WalletDetails();
	
	 public WalletDAOImp() {
			
			PropertyConfigurator.configure("resources//log4j.properties");
		}
	@Override
	public long createAcc(WalletDetails wd) throws WalletException {
		// TODO Auto-generated method stub
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		Long accNo=405109802307l;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,wd.getAccttype());
			preparedStatement.setString(2,wd.getName());
			preparedStatement.setString(3,wd.getMobile());
			preparedStatement.setString(4,wd.getEmail());
			preparedStatement.setString(5,wd.getAddress());
			preparedStatement.setString(6,wd.getAadhar());
			preparedStatement.setDouble(7,wd.getBalance());
			preparedStatement.setString(8,wd.getAge());
			preparedStatement.setString(9,wd.getPin());		
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.ACCTNO_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				accNo=(long) resultSet.getInt(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new WalletException("Inserting employee details failed ");

			}
			else
			{
				logger.info("Account created successfully:");
				return (long) accNo;
			}
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
	}
	@Override
	public boolean validate(long acno,String p) throws WalletException {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		Connection connection = DBConnection.getInstance().getConnection();	
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.VALIDATE_QUERY);
			preparedStatement.setLong(1,acno);
			preparedStatement.setString(2,p);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
				return true;
			else
				throw new WalletException("Invalid Account number or pin. Enter the correct details");
			}catch(SQLException sqlException)
		{
				logger.error(sqlException.getMessage());
				sqlException.printStackTrace();
				throw new WalletException("Tehnical problem occured refer log");
			}
			finally
			{
				try 
				{
					preparedStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					logger.error(sqlException.getMessage());
					throw new WalletException("Error in closing db connection");	
				}
			}
	}
	@Override
	public double showBal(long acno) throws WalletException {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		Connection connection = DBConnection.getInstance().getConnection();	
		
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.SHOWBAL_QUERY);
			preparedStatement.setLong(1,acno);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next()) {
				 double bal=resultSet.getDouble("balance");	
				 return bal;
			}
			else
			{
				throw new WalletException("Invalid account number");
			}
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
	}
	
	@Override
	public double deposit(long acno, double amt) throws WalletException {
		// TODO Auto-generated method stub
		if(amt<=0)
		throw new WalletException("Enter the amount greater than 0");
	else
	{
		PreparedStatement preparedStatement=null;	
		ResultSet resultSet = null;
		ResultSet resultSet1 = null;
		int transaId=0;
		int queryResult=0;
		Connection connection = DBConnection.getInstance().getConnection();	
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.DEPOSIT_QUERY);
			preparedStatement.setDouble(1,amt);
			preparedStatement.setLong(2,acno);
			resultSet=preparedStatement.executeQuery();
			preparedStatement = connection.prepareStatement(QueryMapper.SELECT_BALANCE_QUERY);
			preparedStatement.setLong(1,acno);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next()) {
			 double bal=resultSet.getDouble("balance");	
			 
			 
			 preparedStatement=connection.prepareStatement(QueryMapper.INSERT_TRANS_QUERY);
			 preparedStatement.setLong(1,acno);
			 preparedStatement.setString(2,"Deposit"); preparedStatement.setDouble(4,amt);
			 PreparedStatement date=connection.prepareStatement(QueryMapper.DATE_QUERY);
			 resultSet1=date.executeQuery();
			 if(resultSet1.next()) {
				 Date d=resultSet1.getDate(1);
				 preparedStatement.setDate(3, d);
			 }
			
			 queryResult=preparedStatement.executeUpdate();
			 preparedStatement = connection.prepareStatement(QueryMapper.TRANS_QUERY_SEQUENCE);
			 resultSet=preparedStatement.executeQuery();
				if(resultSet.next())
				{
					transId= resultSet.getInt(1);
							
				}
			 return bal;
			 
		}
		else
		{
			throw new WalletException("Invalid account number");
		}
		
	}catch(SQLException sqlException)
	{
		logger.error(sqlException.getMessage());
		sqlException.printStackTrace();
		throw new WalletException("Tehnical problem occured refer log");
	}
	finally
	{
		try 
		{
			preparedStatement.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			logger.error(sqlException.getMessage());
			throw new WalletException("Error in closing db connection");	
		}
	}
	}
}
	@Override
	public double withdraw(long acno, double amt) throws WalletException {
		// TODO Auto-generated method stub
		if(amt<=0)
			throw new WalletException("Enter the amount greater than 0");
		else
		{
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		double bal;
		ResultSet resultSet1 = null;
		ResultSet resultSet2 = null;
		int transaId=0;
		int queryResult=0;
		Connection connection = DBConnection.getInstance().getConnection();	
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.SELECT_BALANCE_QUERY);
			 preparedStatement.setLong(1,acno);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next()) {
				 bal=resultSet.getDouble("balance");
				 if(bal<amt)
					 throw new WalletException("Inufficient Balance in your account");
				 else
				 {
					 preparedStatement=connection.prepareStatement(QueryMapper.WITHDRAW_QUERY);
					 preparedStatement.setDouble(1,amt);
					 preparedStatement.setLong(2,acno);
					 resultSet=preparedStatement.executeQuery();
					 preparedStatement = connection.prepareStatement(QueryMapper.SELECT_BALANCE_QUERY);
					 preparedStatement.setLong(1,acno);
					 resultSet=preparedStatement.executeQuery();
					 if(resultSet.next()) {
						 bal=resultSet.getDouble("balance");
						 preparedStatement=connection.prepareStatement(QueryMapper.INSERT_TRANS_QUERY);
						 preparedStatement.setLong(1,acno);
						 preparedStatement.setString(2,"Withdraw"); preparedStatement.setDouble(4,amt);
						 PreparedStatement date=connection.prepareStatement(QueryMapper.DATE_QUERY);
						 resultSet1=date.executeQuery();
						 if(resultSet1.next()) {
							 Date d=resultSet1.getDate(1);
							 preparedStatement.setDate(3, d);
						 }
						
						 queryResult=preparedStatement.executeUpdate();
						 preparedStatement = connection.prepareStatement(QueryMapper.TRANS_QUERY_SEQUENCE);
						 resultSet2=preparedStatement.executeQuery();
							if(resultSet2.next())
							{
								transId= resultSet2.getInt(1);
										
							}
						 return bal;
					 }
					 else
					 {
						 throw new WalletException("Invalid account number");
					 }
				 }
				 
			}
			else
			 {
				 throw new WalletException("Error");
			 }
		}catch(SQLException sqlException)
	{
		logger.error(sqlException.getMessage());
		sqlException.printStackTrace();
		throw new WalletException("Tehnical problem occured refer log");
	}
	finally
	{
		try 
		{
			preparedStatement.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			logger.error(sqlException.getMessage());
			throw new WalletException("Error in closing db connection");	
		}
	}
		}
	}
	@Override
	public double fundTransfer(long acno, long acno1, double amt) throws WalletException {
		// TODO Auto-generated method stub
		if(amt<=0)
			throw new WalletException("Enter the amount greater than 0");
		else
		{
			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			double bal;
			ResultSet resultSet1 = null;
			int transaId=0;
			int queryResult=0;
			Connection connection = DBConnection.getInstance().getConnection();	
			try {
				
					preparedStatement = connection.prepareStatement(QueryMapper.SELECT_BALANCE_QUERY);
					preparedStatement.setLong(1,acno);
					resultSet=preparedStatement.executeQuery();
					if(resultSet.next()) {
						bal=resultSet.getDouble("balance");
						if(bal<amt)
							throw new WalletException("Inufficient Balance in your account");
						else
						{
							preparedStatement = connection.prepareStatement(QueryMapper.CHECK_QUERY);
						preparedStatement.setLong(1,acno1);
						resultSet=preparedStatement.executeQuery();
						if(resultSet.next())
						{
							preparedStatement=connection.prepareStatement(QueryMapper.WITHDRAW_QUERY);
							preparedStatement.setDouble(1,amt);
							preparedStatement.setLong(2,acno);
							resultSet=preparedStatement.executeQuery();
							preparedStatement=connection.prepareStatement(QueryMapper.DEPOSIT_QUERY);
							preparedStatement.setDouble(1,amt);
							preparedStatement.setLong(2,acno1);
							resultSet=preparedStatement.executeQuery();
							System.out.println("Rs"+amt+" is transferred from your account "+acno+"to account "+acno1);
							preparedStatement = connection.prepareStatement(QueryMapper.SELECT_BALANCE_QUERY);
							preparedStatement.setLong(1,acno);
							resultSet=preparedStatement.executeQuery();
							if(resultSet.next()) {
								bal=resultSet.getDouble("balance");	
								 preparedStatement=connection.prepareStatement(QueryMapper.INSERT_TRANS_QUERY);
								 preparedStatement.setLong(1,acno);
								 preparedStatement.setString(2,"Fund Transfer (D)"); preparedStatement.setDouble(4,amt);
								 PreparedStatement date=connection.prepareStatement(QueryMapper.DATE_QUERY);
								 resultSet1=date.executeQuery();
								 if(resultSet1.next()) {
									 Date d=resultSet1.getDate(1);
									 preparedStatement.setDate(3, d);
								 }
								
								 queryResult=preparedStatement.executeUpdate();
									preparedStatement=connection.prepareStatement(QueryMapper.INSERT_TRANS_QUERY);
									 preparedStatement.setLong(1,acno1);
									 preparedStatement.setString(2,"Fund Transfer (C)"); preparedStatement.setDouble(4,amt);
									 PreparedStatement date1=connection.prepareStatement(QueryMapper.DATE_QUERY);
									 resultSet1=date1.executeQuery();
									 if(resultSet1.next()) {
										 Date d=resultSet1.getDate(1);
										 preparedStatement.setDate(3, d);
									 }
									
									 queryResult=preparedStatement.executeUpdate();
									 preparedStatement = connection.prepareStatement(QueryMapper.TRANS_QUERY_SEQUENCE);
									 resultSet=preparedStatement.executeQuery();
										if(resultSet.next())
										{
											transId= resultSet.getInt(1);
													
										}
								return bal;
							}
							else
							{
								throw new WalletException("Invalid account number");
							}
						}
						else {
						throw new WalletException("Account number to which you want to transfer does not exist");
					}
						}
					
				}else
				{
					throw new WalletException("Error");
				}
				
			}catch(SQLException sqlException)
			{
				logger.error(sqlException.getMessage());
				sqlException.printStackTrace();
				throw new WalletException("Tehnical problem occured refer log");
			}
			finally
			{
				try 
				{
					preparedStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					logger.error(sqlException.getMessage());
					throw new WalletException("Error in closing db connection");	
				}
			}
	}
}
	@Override
	public boolean printTransactions(long acno) throws WalletException {
		// TODO Auto-generated method stub
		TransactionDetail td=new TransactionDetail();
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		Connection connection = DBConnection.getInstance().getConnection();
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.TRANS_QUERY);
			preparedStatement.setLong(1,acno);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()) {
				td.setTransId(resultSet.getInt("transId"));
				td.setAcno(resultSet.getLong("acno"));
				td.setAmount(resultSet.getDouble("amount"));
				td.setTransDate(resultSet.getDate("transDate"));
				td.setTranstype(resultSet.getString("transtype"));
				System.out.println(td);
				 
			}
		
	}catch(SQLException sqlException)
		{
		logger.error(sqlException.getMessage());
		sqlException.printStackTrace();
		throw new WalletException("Tehnical problem occured refer log");
	}
	finally
	{
		try 
		{
			preparedStatement.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			logger.error(sqlException.getMessage());
			throw new WalletException("Error in closing db connection");	
		}
	}
		return false;
		
		
}
}
