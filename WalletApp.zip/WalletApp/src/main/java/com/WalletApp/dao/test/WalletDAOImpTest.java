package com.WalletApp.dao.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.WalletApp.bean.WalletDetails;
import com.WalletApp.dao.WalletDAO;
import com.WalletApp.dao.WalletDAOImp;
import com.WalletApp.exception.WalletException;

public class WalletDAOImpTest {
	WalletDAO wdao=new WalletDAOImp();
	WalletDetails wd= new WalletDetails();
	@Test
	public void testCreateAcc() {
		wd.setAccttype("Current");
		wd.setName("Lucky");
		wd.setMobile("5674356789");
		wd.setEmail("lucky@gmail.com");
		wd.setAddress("Mumbai");
		wd.setAadhar("123123123123");
		wd.setBalance(5000.00);
		wd.setAge("28");
		wd.setPin("8844");
		try {
			wdao.createAcc(wd);
		}catch (WalletException e)
		{
			e.printStackTrace();
		}
	}

	@Test
	public void testValidate() {
		try {
			assertEquals(true,wdao.validate(47, "1922"));
		}catch (WalletException e)
		{
			e.printStackTrace();
		}
		
	}

	@Test
	public void testShowBal() {
		try {
			assertEquals(Double.toString(11100.0), Double.toString(wdao.showBal(49)));
		}catch (WalletException e)
		{
			e.printStackTrace();		}
	}

	@Test
	public void testDeposit() {

try {
	assertEquals(Double.toString(4600.0),Double.toString(wdao.deposit(47,1000.0)));
}catch (WalletException e)
{
	e.printStackTrace();
}
	}

	@Test
	public void testWithdraw() {
		try {
			assertEquals(Double.toString(3600.0),Double.toString(wdao.withdraw(47, 1000.0)));
		}catch (WalletException e)
		{
			e.printStackTrace();
		}
	}

	@Test
	public void testFundTransfer() {
        try {
            assertEquals(Double.toString(2600.0),Double.toString(wdao.fundTransfer(47, 49, 1000)));
            assertEquals(Double.toString(11100.0),Double.toString(wdao.fundTransfer(49, 47, 1000)));
     } catch (WalletException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
     }

	}

	@Test
	public void testPrintTransactions() {
		try {
		boolean b = wdao.printTransactions(47);
       assertEquals(false,b);
 } catch (WalletException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
 }

	}


}
