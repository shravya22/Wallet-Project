package com.walletapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Optional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.walletapp.bean.CustomerDetails;
import com.walletapp.bean.TransactionDetails;
import com.walletapp.db.CustomerDb;
import com.walletapp.exception.WalletException;
import com.walletapp.util.DBConnection;

public class WalletDao implements IWalletDao {
	static HashMap<Long,CustomerDetails>
     customerMap=CustomerDb.getCustomerMap();
	 static HashMap<Integer, TransactionDetails>
     transactionMap=CustomerDb.getTransactionMap();
	 Logger logger=Logger.getRootLogger();
	 int id=0;
	 public WalletDao() {
			
			PropertyConfigurator.configure("resources//log4j.properties");
		}
	 CustomerDetails customer=new CustomerDetails();
	@Override
	public Long addCustomer(CustomerDetails cd) throws WalletException {
/*try {
			
	if(customerMap.size()==0) {
		cd.setAccountNumber(12345678910l);;
	}
	else {
		Optional<Long> accountNumber=customerMap.keySet().stream().max(new Comparator<Long>() {
			@Override
			public int compare(Long x, Long y) {
				return x>y?1:x<y?-1:0;
			}
		});
		Long newAccountNumber=accountNumber.get()+1;
		cd.setAccountNumber(newAccountNumber);;
	}	
	
	customerMap.put(cd.getAccountNumber(),cd);
	return cd.getAccountNumber();
	
}
		catch (Exception ex) {
			throw new WalletException(ex.getMessage());
		}
		*/
		
Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		Long accNo=12345678910l;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QuerryMapper.INSERT_QUERY);

			preparedStatement.setString(1,cd.getAge());
			preparedStatement.setString(2,cd.getCustomerName());
			preparedStatement.setDouble(3,cd.getBalance());
			preparedStatement.setString(4,cd.getAddress());
			preparedStatement.setString(5,cd.getMoblieNumber());
			preparedStatement.setString(6,cd.getAccountType());
			preparedStatement.setString(7,cd.getGender());
			preparedStatement.setString(8,cd.getAtmPin());
					
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QuerryMapper.ACCOUNTNUMBER_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				accNo=(long) resultSet.getInt(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new WalletException("Inserting employee details failed ");

			}
			else
			{
				logger.info("Employee details added successfully:");
				return (long) accNo;
			}
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
		
	}
	@Override
	public CustomerDetails getBalance(Long accnum,String pin) throws WalletException {
		try {
			CustomerDetails customer=customerMap.get(accnum);
			
			if(customer==null) {
				throw new WalletException("customer with the account number "+accnum+" Not existed");
			}
			if(customer.getAtmPin().equalsIgnoreCase(pin)) {
			return customer;
			}
			else {
				throw new WalletException("Invalid user");
			}
			}
			catch(WalletException ex) {
				System.out.println(ex.getMessage());
			}
		return null;
			
	}
	@Override
	public CustomerDetails setDeposit(Long accnum, String pin, String amt) {
		try {
			CustomerDetails customer=customerMap.get(accnum);
			
			if(customer==null) {
				throw new WalletException("customer with the account number "+accnum+" Not existed");
			}
			if(customer.getAtmPin().equalsIgnoreCase(pin)) {
			double balance=customer.getBalance() + Double.parseDouble(amt);
			customer.setBalance(balance);
			id++;
			transactionMap.put(id,new TransactionDetails(accnum,"Deposit",Double.parseDouble(amt),LocalDateTime.now()));
			return customer;
			}
			else {
				throw new WalletException("Invalid user");
			}
			}
		catch(WalletException ex) {
			System.out.println(ex.getMessage());
		}
		return null;
			
	}
	@Override
	public CustomerDetails getWithdraw(Long accnum, String pin, String amt) {
		CustomerDetails customer=customerMap.get(accnum);
		try {
					
			if(customer==null) {
				throw new WalletException("customer with the account number "+accnum+" Not existed");
			}
			if(customer.getAtmPin().equalsIgnoreCase(pin)) {
				if(customer.getBalance() <=Double.parseDouble(amt)) {
					System.out.println("Low Balance");
				
				}
				else {
					double balance=customer.getBalance() - Double.parseDouble(amt);
					customer.setBalance(balance);
					id++;
					transactionMap.put(id,new TransactionDetails(accnum,"Withdraw",Double.parseDouble(amt),LocalDateTime.now()));
					return customer;
				}
			}
			else {
				throw new WalletException("Invalid user");
			}
			}
		catch(WalletException ex) {
			System.out.println(ex.getMessage());
		}		
		return null;
				
	}
	@Override
	public CustomerDetails getFundTransfer(Long accnum, Long oaccnum, String pin, String amt) {
		CustomerDetails customer=customerMap.get(accnum);
		CustomerDetails ocustomer=customerMap.get(oaccnum);
		try {
				if(customer==null || ocustomer==null) {
				throw new WalletException("customer with the account number "+accnum+" Not existed");
			}
			if(customer.getAtmPin().equalsIgnoreCase(pin)) {
				if(customer.getBalance() <=Double.parseDouble(amt)) {
					System.out.println("Low Balance");
				}
						
				else {
					double balance=customer.getBalance() - Double.parseDouble(amt);
					customer.setBalance(balance);
					double obalance=ocustomer.getBalance()+Double.parseDouble(amt);
					ocustomer.setBalance(obalance);
					id++;
					transactionMap.put(id,new TransactionDetails(accnum,"Withdraw",Double.parseDouble(amt),LocalDateTime.now()));
					return customer;
				}
			}
			
			else {
				throw new WalletException("Invalid user");
			}
			}
		catch(WalletException ex) {
			System.out.println(ex.getMessage());
		}		
		return null;
	}
	@Override
	public 	boolean getPrintTransactions(Long accnum, String pin) {
	
			try {
				CustomerDetails customer=customerMap.get(accnum);
				
				if(customer==null) {
					throw new WalletException("customer with the account number "+accnum+" Not existed");
				}
				if(!customer.getAtmPin().equalsIgnoreCase(pin)) {
					throw new WalletException("enter correct pin number");
				}
				else {
					for(int key=1;key<=transactionMap.size();key++) {
					TransactionDetails trans=transactionMap.get(key);
					if(trans.getAccnum().compareTo(accnum)==0) {
					System.out.println(trans);
				}
					}
				}
                }
			catch(WalletException ex) {
				System.out.println(ex.getMessage());
			}
			return false;
			
			
}
}

