package com.walletapp.dao;

public interface QuerryMapper {
	public static final String INSERT_QUERY="INSERT INTO CustomerDetails VALUES(accountnumber_sequence.NEXTVAL,?,?,?,?,?,?,?,?)";
	public static final String ACCOUNTNUMBER_QUERY_SEQUENCE="SELECT accountnumber_sequence.CURRVAL FROM DUAL";
}
