package com.WalletApp.service;

import com.WalletApp.bean.WalletDetails;
import com.WalletApp.exception.WalletException;

public interface WalletService {
	boolean validateDetails(WalletDetails wd) throws WalletException;

	long createAcc(WalletDetails wd) throws WalletException;

	boolean validate(long acno,String p) throws WalletException;

	double showBal(long acno) throws WalletException;

	double deposit(long acno, double amt)throws WalletException;

	double withdraw(long acno, double amt)throws WalletException;

	double fundTransfer(long acno, long acno1, double amt)throws WalletException;

	boolean printTransactions(long acno)throws WalletException;
}
