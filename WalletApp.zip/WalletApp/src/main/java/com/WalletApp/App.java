package com.WalletApp;


import java.util.Scanner;
import org.apache.log4j.Logger;


import org.apache.log4j.PropertyConfigurator;

import com.WalletApp.bean.WalletDetails;
import com.WalletApp.exception.WalletException;
import com.WalletApp.service.WalletService;
import com.WalletApp.service.WalletServiceImp;


public class App 
{
	WalletService ws=new WalletServiceImp();
  	Scanner sc=new Scanner(System.in);
  	static Logger logger = Logger.getRootLogger();
	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log4j.properties");
		App a=new App();
		a.sc.useDelimiter("\n");
		String option=null;
		while(true) {
			System.out.println("====Payment Wallet====");
			System.out.println("1.Create Account\n2.Show Balance\n3.Deposit\n4.Withdraw\n5.Fund Transfer\n6.Print Transactions\n7.Exit");
			System.out.println("Enter your choice");
			option=a.sc.nextLine();
			switch(option)
			{
			case "1":
				a.createAcc();
				break;
			case "2":
				a.showBal();
				break;
			case "3":
				a.deposit();
				break;
			case "4":
				a.withdraw();
			break;
			case "5":
				a.fundTransfer();
				break;
			case "6":
				a.printTransactions();
				break;
			case "7":
				System.exit(0);
			default:
				System.err.println("invalid option choose from 1 to 6");
				break;
			}
		}
		}
    
	public void printTransactions() {
		// TODO Auto-generated method stub
		System.out.println("Enter account number");
		long acno=Long.parseLong(sc.nextLine());
		System.out.println("Enter your pin number");
		String p=sc.nextLine();
		try {
			boolean res=ws.validate(acno,p);
			if(res)
			{
				boolean b=ws.printTransactions(acno);
				/*System.out.println(t.getTranstype());
				System.out.println(t.getDate());
				System.out.println(t.getAmount());*/
			}
		}catch(WalletException e)
		{
			System.err.println("An error occured "+e.getMessage());
		}
		
	}
	public void fundTransfer() {
		// TODO Auto-generated method stub
		System.out.println("Enter your account number");
		long acno=Long.parseLong(sc.nextLine());
		System.out.println("Enter your pin number");
		String p=sc.nextLine();
		System.out.println("Enter the account number to which you want to transfer");
		long acno1=Long.parseLong(sc.nextLine());
		try {
			boolean res=ws.validate(acno,p);
			if(res)
			{
				System.out.println("Enter amount to transfer");
				double amt=Double.parseDouble(sc.nextLine());
				double newbal=ws.fundTransfer(acno,acno1,amt);
				System.out.println("Account balance : " +newbal);
			}
		}catch(WalletException e)
			{
				System.err.println("An error occured "+e.getMessage());
			}
		
	}
	public void withdraw() {
		// TODO Auto-generated method stub
		System.out.println("Enter account number");
		long acno=Long.parseLong(sc.nextLine());
		System.out.println("Enter your pin number");
		String p=sc.nextLine();
		try {
			boolean res=ws.validate(acno,p);
			if(res)
			{
				System.out.println("Enter the amount to be withdrawn");
				double amt=Double.parseDouble(sc.nextLine());
				double newbal=ws.withdraw(acno,amt);
				System.out.println(+amt+ "is withdrawn from account number "+acno);
				System.out.println("Account balance : " +newbal);
				
			}
		}catch(WalletException e)
		{
			System.err.println("An error occured "+e.getMessage());
		}
		
		
	}
	public void deposit() {
		// TODO Auto-generated method stub
		System.out.println("Enter account number");
		long acno=Long.parseLong(sc.nextLine());
		System.out.println("Enter your pin number");
		String p=sc.nextLine();
		try {
			boolean res=ws.validate(acno,p);
			if(res)
			{
				System.out.println("Enter the amount to be deposited");
				double amt=Double.parseDouble(sc.nextLine());
				double newbal=ws.deposit(acno,amt);
				System.out.println(+amt+ "is deposited into account number "+acno);
				System.out.println("Account balance : " +newbal);
				
			}
		}catch(WalletException e)
		{
			System.err.println("An error occured "+ e.getMessage());
		}
		
	}
	public void showBal() {
		// TODO Auto-generated method stub
		System.out.println("Enter your Account number");
		long acno=Long.parseLong(sc.nextLine());
		System.out.println("Enter your pin number");
		String p=sc.nextLine();
		try {
				boolean res=ws.validate(acno, p);
				if(res) {
				double bal=ws.showBal(acno);
				System.out.println("Account balance : "+bal);
				}
		}catch(WalletException e)
		{
			System.err.println("An error occured "+ e.getMessage());
		}
		
		
	}
	public void createAcc() {
		// TODO Auto-generated method stub
		WalletDetails wd=new WalletDetails();
		System.out.println("Enter Account Type");
		wd.setAccttype(sc.nextLine());
		System.out.println("Enter Customer Name");
		wd.setName(sc.nextLine());
		System.out.println("Enter Mobile Number");
		wd.setMobile(sc.nextLine());
		System.out.println("Enter Email id");
		wd.setEmail(sc.nextLine());
		System.out.println("Enter Address");
		wd.setAddress(sc.nextLine());
		System.out.println("Enter Aadhar Number");
		
		wd.setAadhar(sc.nextLine());
		System.out.println("Enter your age");
		wd.setAge(sc.nextLine());
		System.out.println("Enter pin");
		wd.setPin(sc.nextLine());
		wd.setBalance(2000.00);
		try {
			boolean res=ws.validateDetails(wd);
			if(res) {
			long ret= ws.createAcc(wd);
			System.out.println("Your Account is created successfully. Account number : "+ret);
			}
			
		} catch (WalletException e) {
			System.err.println("An error occured "+ e.getMessage());
		}
	}

}

